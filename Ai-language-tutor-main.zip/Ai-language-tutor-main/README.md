# 🌸 AI Language Tutor — Japanese Learning Assistant

An AI-powered Japanese learning application designed to help learners understand Japanese through sentence analysis, grammar explanations, vocabulary learning, and interactive study tools.

## 📸 Screenshots

### Dashboard
![Dashboard](screenshots/dashboard.png)

### Vocabulary Learning
![Vocabulary](screenshots/vocabulary.png)
![Vocabulary](screenshots/vocabulary1.png)

### Grammar Analysis

![Vocabulary](screenshots/flashcards.png)
![Vocabulary](screenshots/listening.png)
![Vocabulary](screenshots/progress.png)



## ✨ Features

- **Japanese Sentence Analysis** — Analyze Japanese sentences and understand their structure.
- **Grammar Explanations** — Learn Japanese grammar with clear explanations.
- **Vocabulary Learning** — Explore vocabulary and understand words in context.
- **Interactive Quizzes** — Test your understanding and reinforce what you've learned.
- **Flashcards** — Review vocabulary and strengthen your memory.
- **Learning Progress** — Support a more structured and consistent learning experience.

## 🛠️ Tech Stack

**Frontend**
- React
- Vite
- JavaScript
- CSS

**Backend**
- Python
- FastAPI
- SQLite

**AI / Language Processing**
- Ollama (local LLM support)
- Japanese language analysis

## 📁 Project Structure

```text
ai-language-tutor/
├── backend/
│   ├── main.py
│   ├── database.py
│   ├── japanese_analyzer.py
│   ├── vocabulary.py
│   ├── vocabulary_db.py
│   └── test_japanese.py
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── App.jsx
│   │   ├── App.css
│   │   ├── index.css
│   │   └── main.jsx
│   ├── package.json
│   └── vite.config.js
├── screenshots/
│   └── dashboard.png
├── .gitignore
└── README.md
```

## 🚀 Getting Started

### Prerequisites

- Python 3.12
- Node.js and npm
- Ollama, if required by the configured AI features

### 1. Clone the repository

```bash
git clone https://github.com/B-Tarun-kumar07/Ai-language-tutor.git
cd Ai-language-tutor
```

### 2. Set up the backend

From the project root, create a Python virtual environment:

**Windows PowerShell**

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
cd backend
```

Install the backend dependencies listed in your project's dependency file. Then start the API:

```powershell
uvicorn main:app --reload
```

The API documentation is available at:

http://127.0.0.1:8000/docs

### 3. Set up the frontend

Open a second terminal from the project root:

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL displayed by Vite in your browser.

### 4. Configure local AI

If your application uses Ollama, install it and download the model configured in your backend. Make sure the model name and connection settings match your application configuration.

## 🎯 Project Goal

Build an interactive Japanese learning assistant that helps learners understand sentences, develop vocabulary, practice grammar, and study more effectively.

## 🔮 Future Improvements

- Voice-based pronunciation and speaking practice
- Interactive conversation exercises
- JLPT-level-based learning
- Improved learning analytics and progress tracking
- Additional study and revision tools

## 👨‍💻 Author

**B. Tarun Kumar**

A personal project combining language learning, AI, and web development.

---

⭐ If you find this project interesting, consider giving the repository a star!